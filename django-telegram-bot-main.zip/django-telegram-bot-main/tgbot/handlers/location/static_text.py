SEND_LOCATION = "Send 🌏🌎🌍"
share_location = "Would you mind sharing your location?"
thanks_for_location = "Thanks for 🌏🌎🌍"
